package models

import "gorm.io/gorm"

// TAREA (CP1): Complete los campos de Inscripcion según lo que muestran las pantallas.
//
// Pistas de trabajo:
//   - Un Inscripcion referencia a una Clase y a un Cliente (claves foráneas).
//   - Recuerde el campo de estado (use las constantes de estados.go) y el total.
//   - Los tests de acceptance/ compilan contra los nombres EXACTOS de los campos.
type Inscripcion struct {
	gorm.Model
	// TODO: agregue aquí los campos.
}
